package com.example.hr.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EMPLOYEE") // az adatbázisban a tábla neve
@Data // getter, setter, toString, stb
@NoArgsConstructor // egy mezőt sem tartalmazó konstruktor
@AllArgsConstructor // minden mezőt tartalmazó konstruktor
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false, length=50)
    private String firstName;

    @Column(nullable=false, length=100)
    private String lastName;

    @Column(nullable=false, length=200)
    private String email;

}