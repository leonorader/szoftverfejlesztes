package com.example.hr.service;

import com.example.hr.domain.Employee;
import com.example.hr.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    // ez az a metódus, ami visszaadja az adatbázisban lévő összes adatot - az employee táblából
    public List<Employee> getEmployees() {
        return employeeRepository.findAll();
    }
}